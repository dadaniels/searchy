<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Searchy | Hicaliber Test</title>
    <link rel="stylesheet" href="assets/css/searchy.css"/>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"/>