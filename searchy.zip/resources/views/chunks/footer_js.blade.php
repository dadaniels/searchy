<script src="assets/js/jquery.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="assets/js/handlebars.js"></script>
<script src="assets/js/script.js"></script>
