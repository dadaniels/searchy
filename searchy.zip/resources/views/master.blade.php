@include('chunks.head')

</head>

<body>

@yield('content')

@include('chunks.footer_js')

@include('chunks.footer')