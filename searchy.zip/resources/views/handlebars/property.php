<script id="property_tpl" type="text/x-handlebars-template">

    <tr id="athlete_{{id}}">
        <td>{{property}}</td>
        <td>${{price}}</td>
        <td>{{bedrooms}}</td>
        <td>{{bathrooms}}</td>
        <td>{{storeys}}</td>
        <td>{{garages}}</td>
    </tr>

</script>